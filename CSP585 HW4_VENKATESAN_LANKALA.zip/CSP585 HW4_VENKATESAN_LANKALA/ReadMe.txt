The following Strategies has been implemented.

1) Sky Colour changes based on time of the day
2) When ever racing is being done when the speed limit is 10 a police car appears and the racers slow down the vehicle.