import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;

public class GoSlow extends Mypaint implements AdditionalPost {
	embrishment embrishmentobject;

	public GoSlow(embrishment c) {
		embrishmentobject = c;
	}

	public void draw(Graphics g) {	
		 String speed = "10";
		 g.setColor( new Color( 000, 000, 000 ) );
		 g.fillRect(272, 48, 5, 23);
		 g.setColor( new Color( 255, 0, 0 ) );
		 g.fillOval(267, 45, 15, 15);		 
		 g.setColor( new Color( 255, 255, 255 ) );
		 g.drawChars(speed.toCharArray(), 0, 2, 267, 58);
		 embrishmentobject.draw(g);

	}

}
