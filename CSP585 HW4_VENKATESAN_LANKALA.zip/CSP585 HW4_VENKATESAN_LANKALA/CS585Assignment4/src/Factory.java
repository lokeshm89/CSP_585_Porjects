import java.util.*;
import java.text.*;

public class Factory {
	
	public Animal[] MakeAnimalObject(){

		Animal[] a = new Animal[2];	
		Date date = new Date();   
		Calendar calendar = GregorianCalendar.getInstance(); 
		calendar.setTime(date);    
		int i = calendar.get(Calendar.HOUR_OF_DAY);
		System.out.println(i);

		if (i < 17){
			 a[0] = new  TortoiseRacerBlue("Tortoise", 50, 80);	
			 a[1] =   new CarRacerGreen("Rabit", 50, 108);
			 return a;
		  }
		else if(i >=17){
			 a[0] = new  TortoiseRacerYellow("Tortoise", 50, 80);	
			 a[1] =   new CarRacerBlack("Rabit", 50, 108);
			 return a;
		  }
		return null;
    
    
	}
    
}
