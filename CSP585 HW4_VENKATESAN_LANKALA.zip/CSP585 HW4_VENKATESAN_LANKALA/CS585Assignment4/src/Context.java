import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Context extends embrishment {

	public embrishment executeDrawRoadStrategy( embrishment e){

		Date date = new Date();   
		Calendar calendar = GregorianCalendar.getInstance(); 
		calendar.setTime(date);    
		int i = calendar.get(Calendar.HOUR_OF_DAY);   

		if (i < 17)
			return (embrishment)	new DrawRoadDay(e);
		else 
			return (embrishment) 	new DrawRoadNight(e);

	}
	
	
	public embrishment executeSignalStrategy( embrishment e){

		Date date = new Date();   
		Calendar calendar = GregorianCalendar.getInstance(); 
		calendar.setTime(date);    
		int i = calendar.get(Calendar.HOUR_OF_DAY);
		if ( (i>6 && i<10) || (i>16 && i<20))
		{
			Values.currentspeed = 10;
			return (embrishment) new GoSlow(e);
		}
		else{
			Values.currentspeed = 70;
			return (embrishment) new NormalSpeed(e);
		}
	}
}