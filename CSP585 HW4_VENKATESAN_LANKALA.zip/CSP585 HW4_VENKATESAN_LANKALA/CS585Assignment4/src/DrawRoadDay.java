import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;

public class DrawRoadDay extends Mypaint implements DrawRoad {
	embrishment embrishmentobject;

	public DrawRoadDay(embrishment c) {
		embrishmentobject = c;
	}

	public void draw(Graphics g) {
		AffineTransform fontAT = new AffineTransform();

		g.setColor(new Color(255, 255, 255));
		g.fillRect(0, 70, 500, 73);
		g.setColor(new Color(255, 255, 255));
		g.fillRect(0, 100, 500, 5);
		g.setColor(new Color(255, 255, 255));

		g.setColor(new Color(18, 243, 25));
		g.fillRect(0, 143, 500, 73);
		g.setColor(new Color(16, 238, 223));
		// Sky Colour
		g.fillRect(0, 0, 500, 70);

		g.setColor(new Color(204, 204, 153));
		g.fillRect(0, 70, 500, 70);
		g.setColor(new Color(239, 239, 70));

		g.fillRect(400, 100, 10, 5);
		g.fillRect(360, 100, 10, 5);
		g.fillRect(320, 100, 10, 5);
		g.fillRect(280, 100, 10, 5);
		g.fillRect(240, 100, 10, 5);
		g.fillRect(200, 100, 10, 5);
		g.fillRect(160, 100, 10, 5);
		g.fillRect(120, 100, 10, 5);
		g.fillRect(80, 100, 10, 5);
		g.fillRect(40, 100, 10, 5);
		embrishmentobject.draw(g);

		Font theFont = g.getFont();
		Font theDerivedFont = theFont.deriveFont(fontAT);
		fontAT.rotate(90 * java.lang.Math.PI / 180);

	}

}
