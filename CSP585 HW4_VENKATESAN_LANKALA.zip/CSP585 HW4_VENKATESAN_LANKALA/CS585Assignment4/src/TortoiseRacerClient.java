import java.awt.Graphics;

import javax.swing.JApplet;

public class TortoiseRacerClient extends JApplet {
	private TortoiseRacerBlue tb = null;
	private TortoiseRacerYellow ty = null;
	private CarRacerBlack cb = null;
	private CarRacerGreen cg = null;
	private PoliceCar pc = null;
	private DrawRoadDay d;
	private Animal[] a;
	embrishment e = new embrishment();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	public void init( ) {	 

		Factory f = new Factory();	  
		resize(500,200);		
		a = f.MakeAnimalObject();
		e = new FinishLine(e);
		e = new clouds (e);
		e = new traffic (e);  
		e = new Context().executeSignalStrategy(e);
		e = new Context().executeDrawRoadStrategy( e);
	}
	public void paint(  Graphics g ){

		if(a[0] instanceof TortoiseRacerBlue ) {
			tb = (TortoiseRacerBlue) a[0]; 
		}else if (a[0] instanceof TortoiseRacerYellow ) {
			ty = (TortoiseRacerYellow) a[0]; 
		}

		if(a[1] instanceof CarRacerBlack ) {
			cb = (CarRacerBlack) a[1]; 	
		}else if (a[1] instanceof CarRacerGreen) {
			cg = (CarRacerGreen) a[1];		 
		}

		pc = new   PoliceCar("Police", 50, 65);

		for ( int i = 0; i < getWidth( ) / 7; i++ )      
		{
			e.draw(g);
			if(tb != null)
			{
				tb.move( );
				tb.draw( g );
				cg.move( );
				cg.draw( g );
				if( (Values.currentspeed == 10) && i>15 )
				{
					pc.move( );				
					pc.draw( g );
					Values.police_present_onscreen = true;
				}
			}
			else if(ty != null)
			{
				ty.move( );
				ty.draw( g );
				cb.move( );
				cb.draw( g );
				if( (Values.currentspeed == 10) && i>15 )
				{
					pc.move( );
				    pc.draw( g );
					Values.police_present_onscreen = true;
				}
			}
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}    

		}
		Values.police_present_onscreen = false;
		System.exit(0);
	}

}
