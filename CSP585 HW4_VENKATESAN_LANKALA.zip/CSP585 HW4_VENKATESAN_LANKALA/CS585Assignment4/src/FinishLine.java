import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;

public  class FinishLine extends  Mypaint  
{
	embrishment embrishmentobject; 
	public FinishLine (embrishment c)
	{
		embrishmentobject = c;
	}
	

	public void draw(Graphics g) 
	{
		g.setColor( new Color( 255, 255, 255 ) );
		g.fillRect(450, 70, 15, 5);
		g.fillRect(450, 80, 15, 5);
		g.fillRect(450, 90, 15, 5);
		g.fillRect(450, 110, 15, 5);
		g.fillRect(450, 120, 15, 5);
		g.fillRect(450, 130, 15, 5);
		g.fillRect(450, 140, 15, 5);
		g.fillRect(450, 70, 3, 73);
		g.fillRect(465, 70, 3, 73);

		 
	}

}
