
public class Values {
	static int currentspeed;
	static boolean police_present_onscreen = false;

	public static int getCurrentspeed() {
		return currentspeed;
	}

	public static void setCurrentspeed(int currentspeed) {
		Values.currentspeed = currentspeed;
	}
	

}
