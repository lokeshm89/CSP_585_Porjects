import java.awt.Graphics;


public interface DrawRoad {
	
	public void draw(Graphics g); 

}
