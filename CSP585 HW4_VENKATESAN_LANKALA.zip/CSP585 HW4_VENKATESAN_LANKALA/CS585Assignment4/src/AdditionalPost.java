import java.awt.Graphics;


public interface AdditionalPost {
	
	public void draw(Graphics g); 

}
