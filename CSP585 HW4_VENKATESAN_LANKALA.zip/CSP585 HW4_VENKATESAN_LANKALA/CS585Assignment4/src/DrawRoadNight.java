import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

public  class DrawRoadNight extends  Mypaint  implements DrawRoad, ImageObserver
{
	embrishment embrishmentobject; 
	public DrawRoadNight (embrishment c)
	{
		embrishmentobject = c;
	}
	

	public void draw(Graphics g) 
	{
			
	//	Toolkit toolkit = Toolkit.getDefaultToolkit();
	//	Image image1 = toolkit.getImage("/resources/Night.jpg");
		AffineTransform fontAT = new AffineTransform(); 

		
		g.setColor( new Color( 255, 255, 255 ) );
	    g.fillRect(0, 70, 500, 73);
		g.setColor( new Color( 255, 255, 255 ) );
		g.fillRect(0, 100, 500, 5);
		g.setColor( new Color( 255, 255, 255 ) );
		
		g.setColor( new Color( 18 , 243, 25 ) );
		g.fillRect(0, 143, 500, 73);
		//Sky Colour
		g.setColor( new Color( 0 , 0, 0 ) );		
		g.fillRect(0, 0, 500, 70);
		
		g.setColor( new Color( 204, 204, 153) );
		g.fillRect(0, 70, 500, 70);
		g.setColor( new Color( 239 , 239, 70 ) );
				
		// TODO Add Fill to draw stars and moon
		
    	g.setColor( new Color( 255, 255, 255) );
    	g.fillOval(200, 15, 25, 25);
    	g.setColor( new Color( 0, 0, 0) );
    	g.fillOval(197, 10, 25, 25);
		// g.drawImage(image1, 0, 0, 500, 70,  this );
		
			
		g.fillRect(400, 100, 10, 5);
		g.fillRect(360, 100, 10, 5);
		g.fillRect(320, 100, 10, 5);
		g.fillRect(280, 100, 10, 5);
		g.fillRect(240, 100, 10, 5);
		g.fillRect(200, 100, 10, 5);
		g.fillRect(160, 100, 10, 5);
		g.fillRect(120, 100, 10, 5);
		g.fillRect(80, 100, 10, 5);
		g.fillRect(40, 100, 10, 5); 
		embrishmentobject.draw(g);
			
		
		Font theFont = g.getFont();
		Font theDerivedFont = theFont.deriveFont(fontAT);
		fontAT.rotate(90 * java.lang.Math.PI/180);
				 
		 
	}


	@Override
	public boolean imageUpdate(Image arg0, int arg1, int arg2, int arg3,
			int arg4, int arg5) {
		// TODO Auto-generated method stub
		return false;
	}

}

