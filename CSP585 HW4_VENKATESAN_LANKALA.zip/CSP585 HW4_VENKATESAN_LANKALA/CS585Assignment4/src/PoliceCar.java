import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;


public class PoliceCar extends Animal implements Moveable  {
	static int light_ind = 0;

	public PoliceCar( String rID, int rX, int rY ) {
		super( rID, rX, rY );
	}
	public void draw( Graphics g ) {

		Random randomGenerator = new Random();
		int startX = getX( );    int startY = getY( );    
		String txt_police = "P";
		//Tyres
		g.setColor( new Color( 000, 000, 000 ) );     
		g.fillOval( startX + 17, startY + 20,  10, 10 );
		g.fillOval( startX - 7  , startY + 20,  10, 10 );


		g.setColor( new Color( 000, 000, 000 ) );
		g.fillRect(startX+10, startY+13, 20, 13);
		g.fillRect(startX-10, startY+13, 20, 13);

		//Police Head Part
		g.setColor( new Color( 255, 255, 255 ) ); 
		g.fillRect(startX, startY+6, 17, 20);

		// Police Light
		if(light_ind == 0){
			g.setColor( new Color( 255, 0, 0 ) ); 
			g.fillRect(startX, startY+6, 7, 3);
			g.setColor( new Color( 0, 0, 255 ) ); 
			g.fillRect(startX+5, startY+6, 7, 3);
			g.setColor( new Color( 255, 0, 0 ) ); 
			g.fillRect(startX+10, startY+6, 7, 3);
			g.setColor( new Color( 0, 0, 255 ) ); 
			g.fillRect(startX+15, startY+6, 7, 3);
			light_ind = 1;
		}
		else {
			g.setColor( new Color( 0, 0, 255 ) ); 
			g.fillRect(startX, startY+6, 7, 3);
			g.setColor( new Color( 255, 0, 0 ) ); 
			g.fillRect(startX+5, startY+6, 7, 3);
			g.setColor( new Color( 0, 0, 255 ) ); 
			g.fillRect(startX+10, startY+6, 7, 3);
			g.setColor( new Color( 255, 0, 0 ) ); 
			g.fillRect(startX+15, startY+6, 7, 3);
			light_ind = 0;
		}
		// Police Main Body
		g.setColor( new Color( 0, 0, 0 ) );
		g.drawChars(txt_police.toCharArray(), 0, 1, startX+07, startY+22);


	}
	public void move( ) { 
		Random randomGenerator = new Random();
		setX( getX( )+ 2 ); }
}
