import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;


public class RabitRacer extends Animal implements Moveable  {

   public RabitRacer( String rID, int rX, int rY ) {
   super( rID, rX, rY );
   }
   public void draw( Graphics g ) {
	   
	 Random randomGenerator = new Random();
     int startX = getX( );    int startY = getY( );    
     g.setColor( new Color( 255, 200, 135 ) ); 
     g.fillOval( startX, startY, 20, 15 );
     g.fillOval( startX + 17, startY + 1,  10, 39 );
     g.clearRect( startX , startY + 10, 35, 50 );
     g.fillRect( startX + 2, startY + 9 , 13, 4);
     g.fillOval( startX - 3, startY + 6,  7, 7 );
     
       
   }
    public void move( ) { setX( getX( ) + SLOW ); }
}
