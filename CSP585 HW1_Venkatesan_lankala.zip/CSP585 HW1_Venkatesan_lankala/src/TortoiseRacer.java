import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;


public class TortoiseRacer extends Animal implements Moveable  {
   public TortoiseRacer( ) { super( ); }
   public TortoiseRacer( String rID, int rX, int rY ) {
     super( rID, rX, rY );
   }
   public void draw( Graphics g ) {
	   Random randomGenerator = new Random();
     int startX = getX( );    int startY = getY( );
     g.setColor( new Color( randomGenerator.nextInt(255), randomGenerator.nextInt(255), randomGenerator.nextInt(255) )) ; 
    g.fillOval( startX, startY, 25, 15 );
     g.fillOval( startX + 20, startY + 5,  15, 10 );
      g.clearRect( startX, startY + 11, 35, 4 );
     //feet
     g.setColor( new Color( randomGenerator.nextInt(255), randomGenerator.nextInt(255), randomGenerator.nextInt(255) ) );  // brown
     g.fillOval( startX + 3, startY + 10,  5, 5 );
     g.fillOval( startX + 17, startY + 10, 5, 5 );
   }
    public void move( ) { setX( getX( ) + SLOW ); }
}
