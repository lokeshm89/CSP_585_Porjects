import java.awt.Graphics;

import javax.swing.JApplet;

public class TortoiseRacerClient extends JApplet {
  private TortoiseRacer t;
  private RabitRacer r;

  public void init( ) {
    t = new TortoiseRacer( "Tortoise", 50, 50 );
    r = new RabitRacer( "Rabit", 50, 75 );
  }
  public void paint( Graphics g ) {
    for ( int i = 0; i < getWidth( ); i++ )      {
      t.move( );
      t.draw( g );
      r.move( );
      r.draw( g );
      try {
		Thread.sleep(100);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    //Pause.wait( .03 );
     g.clearRect( 0, 0, getWidth( ), getHeight( ) );
    }
  }
}
