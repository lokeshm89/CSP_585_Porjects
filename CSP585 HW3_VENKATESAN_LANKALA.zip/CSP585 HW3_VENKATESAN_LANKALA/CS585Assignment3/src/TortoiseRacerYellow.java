import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;


public class TortoiseRacerYellow extends Animal implements Moveable  {
   public TortoiseRacerYellow( ) { super( ); }
   public TortoiseRacerYellow( String rID, int rX, int rY ) {
     super( rID, rX, rY );
   }
   public void draw( Graphics g ) {
	 
	 Random randomGenerator = new Random();
     int startX = getX( );    
     int startY = getY( );
     g.setColor( new Color( 239, 239,70 )) ; 
     g.fillOval( startX, startY, 25, 15 );
     g.fillOval( startX + 20, startY + 5,  15, 10 );
     g.setColor( new Color( 239, 239,70 ) );
     g.fillRect( startX, startY + 11, 35, 4 );
     
     //feet
     
     g.setColor( new Color( 239, 239,70 ) );  // brown
     g.fillOval( startX + 3, startY + 10,  5, 5 );
     g.fillOval( startX + 17, startY + 10, 5, 5 );
   }
    public void move( ) { 
    	 Random randomGenerator = new Random();
    	 setX( getX( )+randomGenerator.nextInt(10) + randomGenerator.nextInt(5) ); }
}
