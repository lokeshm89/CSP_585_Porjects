import java.awt.Color;
import java.awt.Graphics;

public class embrishment
{
	public embrishment ()
	{
	}
	
	public  void draw( Graphics g )
	{
	
	}
}
