import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;

public  class clouds extends   Mypaint  
{
	embrishment embrishmentobject; 
	public clouds (embrishment c)
	{
		embrishmentobject = c;
	}
	

	public void draw(Graphics g) 
	{
		g.setColor( new Color( 255, 255, 255 ) );
		g.fillOval( 70, 20, 30, 15 );
		g.fillOval( 80, 16, 30, 15 );
		g.fillOval( 90, 20, 30, 15 );
		
		g.fillOval( 250, 20, 30, 15 );
		g.fillOval( 260, 24, 30, 15 );
		g.fillOval( 250, 20, 30, 15 );
		 
		g.fillOval( 340, 20, 30, 15 );
		g.fillOval( 335, 16, 30, 15 );
		g.fillOval( 330, 20, 30, 15 );
		 
		g.fillOval( 70, 20, 30, 15 );
		g.fillOval( 80, 16, 30, 15 );
		g.fillOval( 90, 20, 30, 15 );
		embrishmentobject.draw(g);
		 
	}

}
