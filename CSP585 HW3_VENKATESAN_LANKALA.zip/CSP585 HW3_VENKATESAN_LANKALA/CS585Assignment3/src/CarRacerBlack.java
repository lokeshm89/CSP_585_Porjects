import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;


public class CarRacerBlack extends Animal implements Moveable  {

   public CarRacerBlack( String rID, int rX, int rY ) {
   super( rID, rX, rY );
   }
   public void draw( Graphics g ) {
	   
	 Random randomGenerator = new Random();
     int startX = getX( );    int startY = getY( );    
     
     
	 g.setColor( new Color( 000, 000, 000 ) );     
     g.fillOval( startX + 17, startY + 20,  10, 10 );
     g.fillOval( startX - 7  , startY + 20,  10, 10 );
     g.setColor( new Color( 000, 00, 000 ) ); 
     g.fillRect(startX, startY, 20, 15);
     g.fillRect(startX+10, startY+10, 20, 15);
     g.fillRect(startX-10, startY+10, 20, 15);
          
       
   }
    public void move( ) { 
    	 Random randomGenerator = new Random();
    	 setX( getX( )+randomGenerator.nextInt(10) + randomGenerator.nextInt(5) ); }
}
