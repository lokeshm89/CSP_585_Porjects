import java.awt.Graphics;

import javax.swing.JApplet;

public class TortoiseRacerClient extends JApplet {
  private TortoiseRacer t;
  private CarRacer r;
  private drawroad d;
  private traffic a;
  embrishment e = new embrishment(); 
  public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
  public void init( ) {
	 
	resize(500,200);	 
    t = new TortoiseRacer( "Tortoise", 50, 80 );
    r = new CarRacer( "Rabit", 50, 108 );
    
    e = new FinishLine(e);
    e = new clouds (e);
    e = new traffic (e);    
    e = new drawroad(e);
 
  }
  public void paint( Graphics g ) {
    for ( int i = 0; i < getWidth( ) / 7; i++ )      
    {
      e.draw(g);
      t.move( );
      t.draw( g );
      r.move( );
      r.draw( g );
      try {
		Thread.sleep(50);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}    
   //  g.clearRect( 0, 0, getWidth( ), getHeight( ) );
    }
  System.exit(0);
  }
 
}
