import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;

public  class traffic extends   Mypaint  
{
	embrishment embrishmentobject; 
	public traffic (embrishment c)
	{
		embrishmentobject = c;
	}
	

	public void draw(Graphics g) 
	{
		 
		 g.setColor( new Color( 255, 255, 000 ) );
		 g.fillRect(302, 48, 5, 23);
		 g.setColor( new Color( 000, 000, 000 ) );
		 g.fillRect(300, 33, 10, 19);
		 g.setColor( new Color( 255, 000, 000 ) );
		 g.fillOval(300, 31, 10, 5);
		 g.setColor( new Color( 255, 255, 000 ) );
		 g.fillOval(300, 37, 10, 5);
		 g.setColor( new Color( 000, 255, 017 ) );
		 g.fillOval(300, 42, 10, 5);
		 embrishmentobject.draw(g);
		 
		 
		 
		 
	}

}
