import java.awt.Graphics;

public abstract class Mypaint extends embrishment
{
	public abstract void draw(Graphics g);
}

